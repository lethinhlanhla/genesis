
package track;

import java.io.File;
import java.io.IOException;

/**
 * Creates the Suzuka track for car racing.
 *
 */
public class SuzukaTrack extends ATrack
{
	/** The file containing the data for the track */
	protected File file;
	
	/** The track race information */
	private int[] track;
	
	/**
	 * Constructor.
	 * 
	 * @param fileDirectory
	 * 	The directory of the file.
	 * @param trackFilename
	 * 	The name of the file.
	 */
	public SuzukaTrack(File fileDirectory, String trackFilename)
	{
		init(fileDirectory, trackFilename);
	}
	
	/**
	 * Retreives the track information on intialization of the track.
	 * 
	 * @param fileDirectory
	 * 	The directory of the file.
	 * @param trackFilename
	 * 	The name of the file.
	 */
	private void init(File fileDirectory, String trackFilename)
	{
		
		try
		{
			if ((file = fileExists(fileDirectory, trackFilename)) != null)
			{
				if(!isValidTrack(createTrack(readTrackFile(file))))
				{
					this.track = DEFAULT_TRACK;
				}
			}
		}
		catch (IOException e)
		{
			this.track = DEFAULT_TRACK;
			e.printStackTrace();
		}
		
	}
	
	@Override
	public int[] getTrack()
	{
		return track;
	}
	
	@Override
	protected boolean isValidTrack(String[] track)
	{
		this.track = new int[track.length];

		for(int i = 0; i < track.length; i++)
		{
			try
			{
				int num = Integer.parseInt(track[i]);
				if (num == this.STRAIGHT_LINE || num == this.CORNERS)
				{
					this.track[i] = num;
				}
				else
				{
					this.track = null;
					return false;
				}
				
			}
			catch(NumberFormatException e)
			{
				e.printStackTrace();
				this.track = null;
				return false;	
			}
		}	
		return true;
	}
	
	@Override
	protected String[] createTrack(String trackData)
	{
			
		String[] track = new String[trackData.length()];
		
		for(int i = 0; i<trackData.length(); i++)
		{
			if((i+1) != trackData.length())
			{
				track[i] = trackData.substring(i,i+1);
			}
			else
			{
				track[i] = trackData.substring(i);
			}
		}
		
		return track;
	}

	@Override
	public String toString()
	{
		StringBuilder stringbuild = new StringBuilder();
		
		for(int t : track)
			stringbuild.append(t);
		
		return stringbuild.toString();
	}
	
}
