package track;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
/**
 * This is an abstract base class for all Racing Game Tracks.
 *
 */
public abstract class ATrack
{
	
	/** represents the straight lines of the track */
	public static final int STRAIGHT_LINE = 0;
	
	/** represents the cornner of the track */
	public static final int CORNERS = 1;
	
	/** default track is used when unable to retieve the track from the file */
	protected static final int [] DEFAULT_TRACK = {0,0,0,1,1};
	
	/**
	 * Checks if the given directory and file exist.
	 * 
	 * @param fileDirectory 
	 * 		The file directory.
	 * @param trackFilename
	 * 		The file name.
	 * @return File to be read or, <code>null</code> otherwise.
	 */
	public static File fileExists(File fileDirectory, String trackFilename)
	{
		File file = new File(fileDirectory.getAbsolutePath() + File.separator.concat(trackFilename));
		if (file.exists())
		{
			return file;
		}
		
		return null;
	}
	
	/**
	 *Reads the file line by line.
	 * 
	 * @param file
	 * 		The file to be read
	 * @return String represenation of the file contents.
	 * @throws IOException
	 */
	protected String readTrackFile(File file) throws IOException
	{
		
		try (BufferedReader bufferReader = new BufferedReader(new FileReader(file.getAbsolutePath())))
		{
			
			StringBuilder buildTrack = new StringBuilder();
			String read;
			
			while ((read = bufferReader.readLine()) != null)
			{
				buildTrack.append(read);
			}
			
			return buildTrack.toString();
		}
	}
	
	/**
	 * Splits the given string to a string array.
	 * 
	 * @param trackData
	 * 		The track data from the file.
	 */
	protected abstract String[] createTrack(String trackData);
	
	/**
	 * Vadiates the track array either contains straight lines or 
	 * curves only.
	 * 
	 * @param track
	 * @return True if the track contains zeros and ones and, False otherwise.
	 */
	protected abstract boolean isValidTrack(String[] track);
	
	/**
	 * Gets the track information.
	 * @return an array of type int representing the track.
	 */
	public abstract int[] getTrack();
	
	@Override
	public abstract String toString();
}
