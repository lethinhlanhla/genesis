import java.io.File;
import java.util.Scanner;

import cars.Car;
import track.*;

public class Race
{
	ATrack track;
	Car[] cars;
	
	/**
	 * Constructor.
	 * 
	 * @param track
	 *           The track used for the race
	 * @param cars
	 *           The cars used for the race
	 */
	public Race(ATrack track, Car[] cars)
	{
		this.track = track;
		this.cars = cars;
		
	}
	
	/**
	 * Starts the race and waits until all the cars have finished the race
	 */
	private void start()
	{
		int[] raceTrack = track.getTrack();
		for (int t = 0; t < raceTrack.length; t++)
		{
			for (int c = 0; c < cars.length; c++)
			{
				if (raceTrack[t] == ATrack.STRAIGHT_LINE)
				{
					cars[c].accelerate();
					
				}
				
				if (raceTrack[t] == ATrack.CORNERS)
				{
					cars[c].cornering();
				}
			}
		}
		
	}
	
	/**
	 * Gets the winner of the race, if there is a tie between cars the first car entered into the
	 * race wins.
	 * 
	 * @return Car that won.
	 */
	private Car winner()
	{
		Car winner = cars[0];
		for (int c = 0; c < cars.length; c++)
		{
			
			if (winner.trackRate < cars[c].trackRate)
			{
				winner = cars[c];
			}
		}
		
		return winner;
	}
	
	/**
	 * Starts the track race.
	 * 
	 * @param args
	 */
	public static void main(String[] args)
	{
		final String directoryName = "resources";
		File directory = new File(directoryName);
		String filename = "track.txt";
		Scanner scan = new Scanner(System.in);
		while (true)
		{
			System.out.println(
				"-----------------------------------------------------------------------------------------------------------------------------");
			System.out.println(
				"Please enter the name of the file you wish to load for the race located in the resources folder and also add the file extention");
			String input = scan.nextLine();
			
			while (ATrack.fileExists(directory, filename) == null)
			{
				System.out.println(
					"Please enter another file name, the one you entered " + input + " does not exist");
				input = scan.nextLine();
			}
			
			System.out.println(
				"-----------------------------------------------------------------------------------------------------------------------------");
			SuzukaTrack track = new SuzukaTrack(directory, filename);
			System.out.println("This is the chosen track for this race:");
			System.out.println(track.toString());
			
			System.out.println(
				"-----------------------------------------------------------------------------------------------------------------------------");
				
			System.out.println(
				"Four cars have to race at the same time please enter the following car details");
			Car[] cars = new Car[4];
			
			System.out.println(
				"-----------------------------------------------------------------------------------------------------------------------------");
						for (int i = 0; i < cars.length; i++)
			{
				System.out.println("Please enter the car name");
				String name = scan.nextLine();
				try
				{
					System.out.println("Please enter the acceleration");
					int acc = Integer.parseInt(scan.nextLine());
					
					System.out.println("Please enter the top speed");
					int ts = Integer.parseInt(scan.nextLine());
					
					System.out.println("Please enter the corner speed");
					int con = Integer.parseInt(scan.nextLine());
					
					cars[i] = new Car(name, acc, ts, con);
					System.out.println(cars[i].toString());
				}
				catch (NumberFormatException e)
				{
					e.printStackTrace();
					System.exit(0);
					
				}
			}
		System.out.println(
							"---------------------------------------------Winner-----------------------------------------------------------------------");
									
			Race race1 = new Race(track, cars);
			race1.start();
			Car cr = race1.winner();
			System.out.println(cr.toString());
			System.out.println("Winner's Speed = "+ cr.trackRate);
			System.exit(0);
		}
		
	}
	
}
