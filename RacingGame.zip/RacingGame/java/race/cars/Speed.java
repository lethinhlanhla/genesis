package cars;

public class Speed
{
	protected int acceleration;
	protected int topSpeed;
	protected int cornering;
	
	public Speed(int acceleration, int topSpeed, int cornering)
	{
		this.acceleration = acceleration;
		this.topSpeed = topSpeed;
		this.cornering = cornering;
	}
	
}
