package cars;

public class Car
{
	public String name;
	protected Speed speed;
	protected int currentAcceleration;
	public int trackRate;
	
	
	public Car(String name, int acceleration, int topSpeed, int cornering)
	{
		this.name = name;
		trackRate = 0;
		currentAcceleration = 0;
		speed = new Speed(acceleration, topSpeed, cornering);
	}
	
	public Car(int acceleration, int topSpeed, int cornering)
	{
		trackRate = 0;
		currentAcceleration = 0;
		speed = new Speed(acceleration, topSpeed, cornering);
	}

	public int accelerate()
	{
		if((currentAcceleration + speed.acceleration) <= speed.topSpeed)
		{
			currentAcceleration = currentAcceleration + speed.acceleration;
		}
		else
		{
			currentAcceleration = speed.topSpeed;
		}
		trackRate = trackRate + currentAcceleration;
		
		return currentAcceleration;
	}
	
	public int cornering()
	{
		currentAcceleration = speed.cornering;
		trackRate = trackRate + currentAcceleration;
		
		return currentAcceleration;
	}
	
	protected void stationary()
	{
		trackRate = 0;
		currentAcceleration = 0;
	}
	
	public String toString()
	{
		String car = name +":\n A : "+speed.acceleration+"\n TS : "+speed.topSpeed+"\n C : "+speed.cornering;
		return car;
	}
}
